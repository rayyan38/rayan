<?php
$koneksi = mysqli_connect("localhost", "root", "", "ukk2");

if (isset($_GET['id'])) {
  $nis = $_GET['id'];
  $result = mysqli_query($koneksi, "SELECT * FROM tbl_siswa WHERE nis='$nis'");
  $data = mysqli_fetch_assoc($result);
}

if (isset($_POST['update'])) {
  $nomor_test = $_POST['nomor_test'];
  $tanggal_tes = $_POST['tanggal_tes'];
  $bersedia = $_POST['bersedia_mengikutites'];

  mysqli_query($koneksi, "UPDATE tbl_siswa SET 
      nomor_test='$nomor_test', 
      tanggal_tes='$tanggal_tes', 
      bersedia_mengikutites='$bersedia' 
      WHERE nis='$nis'");

  header("Location: tabel.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="hayaa.css">
  <title>Edit Data</title>
  <style>
    form {
      max-width: 400px;
      margin: 20px auto;
    }
    input, select, button {
      display: block;
      width: 100%;
      margin-bottom: 10px;
      padding: 8px;
    }
  </style>
</head>
<body>

  <h2>Edit Data Siswa</h2>

  <form method="POST">
    <label>Nomor Tes:</label>
    <input type="text" name="nomor_test" value="<?= $data['nomor_test']; ?>" required>

    <label>Tanggal Tes:</label>
    <input type="date" name="tanggal_tes" value="<?= $data['tanggal_tes']; ?>" required>

    <label>Bersedia Mengikuti Tes:</label>
    <select name="bersedia_mengikutites" required>
      <option value="bersedia" <?= $data['bersedia_mengikutites'] == 'bersedia' ? 'selected' : '' ?>>Bersedia</option>
      <option value="tidak bersedia" <?= $data['bersedia_mengikutites'] == 'tidak bersedia' ? 'selected' : '' ?>>Tidak Bersedia</option>
    </select>

    <button type="submit" name="update">Update</button>
  </form>

</body>
</html>