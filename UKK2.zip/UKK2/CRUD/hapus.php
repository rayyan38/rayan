<?php
$koneksi = mysqli_connect("localhost", "root", "", "ukk2");

if (isset($_GET['id'])) {
    $nis = $_GET['id'];
    $hapus = mysqli_query($koneksi, "DELETE FROM tbl_siswa WHERE nis='$nis'");

    if ($hapus) {
        header("Location: tabel.php");
    } else {
        echo "Gagal menghapus data.";
    }
} else {
    echo "NIS tidak ditemukan.";
}
?>
